
## Usage

Install dependencies

```
pip install sphinx sphinx_rtd_theme myst-parser
```

Generate html

```shell
# in the root directory
bash build.sh
```
